from django.contrib import admin
from django.urls import path, include


urlpatterns = [
    path('admin/', admin.site.urls),
    path('register/', include('users.urls')),
    path('auth/', include('django.contrib.auth.urls')),
    path('api/',  include('api.urls')),
    path('', include('wash.urls')),
]
